# # # # 
# # # # Input :Enter the type of food you're craving: indian

# # # # Output: Recommended Restaurants:
# # # # Name: Pamrampara, Rating: 5, Distance: 8 km, Location: Hyderabad
# # # # Name: Chutneys, Rating: 4.2, Distance: 4 km, Location: Hyderabad
# # # # Name: Bikanervala, Rating: 4.1, Distance: 4 km, Location: Hyderabad

# # # # Input: Enter the type of food you're craving: Mexican

# # # # Ouput: Recommended Restaurants:

# # # # Name: Alchemy, Rating: 3.5, Distance: 5 km, Location: Hitechcity

# # # # Input: Enter the type of food you're craving: italian

# # # # Output: Recommended Restaurants:
# # # # Name: Olive Bistro, Rating: 4.5, Distance: 3 km, Location: Madhapur
# # # # Name: Tre-Forni Bar & Restaurant, Rating: 4.5, Distance: 6 km, Location: Kondapur
# # # # Name: Ci Gusta!, Rating: 4.2, Distance: 1 km, Location: kukatpally

# # # Input: Enter the type of food you're craving: north indian

# # # Output: Recommended Restaurants:
# # # Name: Santhosh Daba, Rating: 4.3, Distance: 2 km, Location: Hafeezpet

# # Input: Enter the type of food you're craving: thai

# # Output:Recommended Restaurants:
# # Name: Mamagoto, Rating: 4.5, Distance: 6 km, Location: Kondapur
# # Name: Haiku, Rating: 4.3, Distance: 8 km, Location: Hitech City

